﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Jewels_app
{
    public partial class dahbaord : UserControl
    {
        public dahbaord()
        {
            InitializeComponent();
        }
    }
}
