﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Jewels_app
{
    public partial class customerOrder : UserControl
    {
        public customerOrder()
        {
            InitializeComponent();
        }
    }
}
